from pr.pr import programa

programa()